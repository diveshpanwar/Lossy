<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Image Optimizer</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Divesh Panwar">
    <meta name="Description" content="Image Compression and Resizing">
    <meta name="version" content="1.0">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
      *{
        font-family: 'Lobster', cursive;
      }
      body {
        line-height: normal;
      }

    .range {
        display: table;
        position: relative;
        height: 25px;
        margin-top: 5px;
        background-color: rgb(245, 245, 245);
        border-radius: 4px;
        -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    }

    .range input[type="range"] {
        -webkit-appearance: none !important;
        -moz-appearance: none !important;
        -ms-appearance: none !important;
        -o-appearance: none !important;
        appearance: none !important;

        display: table-cell;
        width: 100%;
        background-color: transparent;
        height: 25px;
        cursor: pointer;
    }
    .range input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none !important;
        -moz-appearance: none !important;
        -ms-appearance: none !important;
        -o-appearance: none !important;
        appearance: none !important;

        width: 11px;
        height: 25px;
        color: rgb(255, 255, 255);
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 0px;
        background-color: rgb(153, 153, 153);
    }

    .range input[type="range"]::-moz-slider-thumb {
        -webkit-appearance: none !important;
        -moz-appearance: none !important;
        -ms-appearance: none !important;
        -o-appearance: none !important;
        appearance: none !important;

        width: 11px;
        height: 22px;
        color: rgb(255, 255, 255);
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 0px;
        background-color: rgb(153, 153, 153);
    }

    .range output {
        display: table-cell;
        padding: 3px 5px 2px;
        min-width: 40px;
        color: rgb(255, 255, 255);
        background-color: rgb(153, 153, 153);
        text-align: center;
        text-decoration: none;
        border-radius: 4px;
        border-bottom-left-radius: 0;
        border-top-left-radius: 0;
        width: 1%;
        white-space: nowrap;
        vertical-align: middle;

        -webkit-transition: all 0.5s ease;
        -moz-transition: all 0.5s ease;
        -o-transition: all 0.5s ease;
        -ms-transition: all 0.5s ease;
        transition: all 0.5s ease;

        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: -moz-none;
        -o-user-select: none;
        user-select: none;
    }
    .range input[type="range"] {
        outline: none;
    }

      .range.range-primary input[type="range"]::-webkit-slider-thumb {
          background-color: rgb(92, 184, 92);
      }
      .range.range-primary input[type="range"]::-moz-slider-thumb {
          background-color: rgb(92, 184, 92);
      }
      .range.range-primary output {
          background-color: rgb(92, 184, 92);
      }
      .range.range-primary input[type="range"] {
          outline-color: rgb(92, 184, 92);
      }
      .newHr {
        border: 1px solid rgb(92, 184, 92);
        width: 80%;
      }

    </style>
  </head>
  <body>
    <div class="container">
        <h1 class="text-success text-center">Optimize Images</h1>
        <hr class='newHr'>
      <div class="row">
        <div class="col-md-6 offset-md-3">
          <form class="form text-center" action="upload.php" method="post" enctype="multipart/form-data" name="imageOptimizer">
            <div class="form-group">
            <input type="file" class="form-control" name="userImage" id="userImage" required>
            </div>
            <div class="form-group">
            <input type="number" class="form-control" name="userWidth" id="userWidth" required placeholder="Width in pixels (any valid number)">
            </div>
            <div class="form-group">
            <input type="number" class="form-control" name="userHeight" id="userHeight" required placeholder="Height in pixels (any valid number)">
            </div>
            <div class="form-group  ">
              <label class="text-center">Choose Quality</label>
              <div class="range range-primary">
                <input type="range" name="range" min="1" max="100" value="50" onchange="rangePrimary.value=value">
                <output id="rangePrimary">50</output>
              </div>
            </div>
            <div class="form-group text-center">
            <input type="submit" value="Upload and Optimize" class="btn btn-success text-center">
            </div>
          </form>
      </div>
      </div>
    </div>

    <div id="footer" class="footer" style="margin-top: 10%;">
      <div class="container text-center">
        <p class="text-muted credit" style="color:#fff">Developed with the intention to help you... Just a Version 1.0. Other features are under deveopment.(Created for Pankaj Chauhan)</p>
      </div>
    </div>
  </body>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</html>
