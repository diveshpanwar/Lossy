<?php
  session_start();
  if(isset($_FILES['userImage']) && !empty($_FILES['userImage']) && isset($_POST['userWidth']) && !empty($_POST['userWidth'])  && isset($_POST['userHeight']) && !empty($_POST['userHeight'])){

    $userImage_name = $_FILES['userImage']['name'];
    $userImage_tempName = $_FILES['userImage']['tmp_name'];
    $userImage_extension = pathinfo($userImage_name, PATHINFO_EXTENSION); //file extension

    $userWidth = $_POST['userWidth'];
    $userHeight = $_POST['userHeight'];
    $userQuality = $_POST['range'];

    $destination = 'upload';
    $_SESSION['imageName'] = $userImage_name;

    if($userImage_extension == 'png' || $userImage_extension == 'PNG'){
      $src = imagecreatefrompng($userImage_tempName);
    }elseif ($userImage_extension == 'jpg' || $userImage_extension == 'jpeg' || $userImage_extension == 'JPG' || $userImage_extension == 'JPEG') {
      $src = imagecreatefromjpeg($userImage_tempName);
    }elseif ($userImage_extension == 'gif' || $userImage_extension == 'GIF') {
      $src = imagecreatefromgif($userImage_tempName);
    }

    $moved_file = move_uploaded_file($userImage_tempName, "$destination/$userImage_name");

    if($moved_file){
      echo "<h2 align='center'>File Uploaded Successfully.</h2>";
    } else {
      echo "<h2 align='center'>File not Uploaded</h2>";
    }

    list($width_min, $height_min) = getimagesize("$destination/$userImage_name");

    // $new_width_min = 360;
    // $new_height_min = ($height_min/$width_min) * $new_width_min;

    $new_width_min = $userWidth;
    $new_height_min = $userHeight;

    $tmp_min = imagecreatetruecolor($new_width_min, $new_height_min);

    imagecopyresampled($tmp_min, $src, 0,0,0,0, $new_width_min, $new_height_min, $width_min, $height_min);

    imagejpeg($tmp_min, "optimized/".$userImage_name,$userQuality);

    header('Location: upload.php');

  }


?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Image Optimizer</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Divesh Panwar">
    <meta name="version" content="1.0">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
      *{
        font-family: 'Lobster', cursive;
      }

      .stylize{
        font-family: 'Lobster', cursive;
      }

      .newHr {
        border: 1px solid rgb(92, 184, 92);
        width: 80%;
      }
    </style>
  </head>
  <body>

    <?php
      if(isset($_SESSION['imageName'])){

        if(file_exists("optimized/".$_SESSION['imageName'])){
              echo "<div class='text-center'>";
              echo '<h1 class="text-success text-center stylize">Optimized Image</h1><hr class="newHr">';
              echo "<img class='img-fluid text-cennter rounded' style='max-width: 100vw;' src='optimized/".$_SESSION['imageName']."'>  ";
              echo "<br><br><a download='optimized/".$_SESSION['imageName']."' href='optimized/".$_SESSION['imageName']."'><button class='btn btn-primary'>Download</button></a>";
              echo "</div>";
            }else {
              echo "<div class='text-center'>";
              echo '<h1 class="text-success text-center stylize">Sorry Something Wrong Happened! Please Try Again...</h1><hr class="newHr">';
              echo "<br><br><a href='index.php'><button class='btn btn-primary'>Back</button></a>";
              echo "</div>";
            }
          }
      ?>
      <div id="footer" class="footer" style="margin-top: 5%;">
        <div class="container text-center">
          <p class="text-muted credit" style="color:#fff">Developed with the intention to help you... Just a Version 1.0. Other features are under deveopment. (Created for Pankaj Chauhan)</p>
        </div>
      </div>
  </body>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</html>
